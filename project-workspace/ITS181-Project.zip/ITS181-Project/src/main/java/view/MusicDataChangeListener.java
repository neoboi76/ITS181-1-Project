package view;

/**
*
* 
*/


public interface MusicDataChangeListener {
	void onDataChanged();
}
